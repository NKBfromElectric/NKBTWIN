NKB Twin VST3 — Windows x64

Cubase install:
1. Extract this archive.
2. Copy the entire "NKB Twin.vst3" folder into your VST3 plug-in scan folder.
   Default Windows folder: C:\Program Files\Common Files\VST3
3. Rescan plug-ins in Cubase and load "NKB Twin" as a stereo insert effect.

The plug-in accepts guitar input, with signal flow Effects -> Amp -> Cabinet.
Standalone ASIO build is also available in the GitHub release.
